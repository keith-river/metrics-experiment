#!/bin/bash
# ハンズオン前の環境チェック
. "$(dirname "$0")/env.sh"
ok=1
chk() { if command -v "$1" >/dev/null 2>&1; then printf '  OK   %s\n' "$1"; else printf '  なし %s   → %s\n' "$1" "$2"; ok=0; fi; }
echo "[ツール]"
chk git "xcode-select --install"
chk clang-format "brew install clang-format  (または brew install llvm)"
chk clang-tidy "brew install llvm して PATH に \$(brew --prefix llvm)/bin を追加"
chk lcov "brew install lcov"
command -v bat >/dev/null 2>&1 && echo "  OK   bat" || echo "  任意 bat（なくても cat で代用可）"
echo "[コンパイラ] CC=$CC"; $CC --version | head -1
echo "[gcov] GCOV=$GCOV"
tmp=$(mktemp -d); cd "$tmp" || exit 1
printf 'int f(int x){ if(x>0){return 1;} return 0; }\nint main(void){ return f(1)-1; }\n' > t.c
if $CC -coverage -o t t.c 2>/dev/null && ./t && $GCOV t.c >/dev/null 2>&1 && [ -f t.c.gcov ]; then
  echo "  OK   カバレッジ計測（$CC + $GCOV）"
else
  echo "  NG   カバレッジ計測。Mac では brew install gcc を試してください"; ok=0
fi
cd - >/dev/null; rm -rf "$tmp"
[ $ok = 1 ] && echo "すべて準備できました" || echo "足りないものがあります（上の案内を参照）"
