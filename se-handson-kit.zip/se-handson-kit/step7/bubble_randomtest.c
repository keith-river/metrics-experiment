#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void bubble_sort(int n, int *arr);

static int cmp_int(const void *x, const void *y) {
    int a = *(const int *)x;
    int b = *(const int *)y;
    return (a > b) - (a < b);
}

int main(void) {
    enum { TRIALS = 10000, MAX_LEN = 64 };
    int data[MAX_LEN];
    int expected[MAX_LEN];
    int failures = 0;
    int trial = 0;

    srand(12345); /* 再現できるよう乱数の種を固定 */
    for (trial = 0; trial < TRIALS; trial++) {
        int len = rand() % (MAX_LEN + 1); /* 0〜64 個 */
        int i = 0;
        for (i = 0; i < len; i++) {
            data[i] = rand() % 101 - 50; /* -50〜50（負数・重複を含む） */
        }
        memcpy(expected, data, sizeof(int) * (size_t)len);
        qsort(expected, (size_t)len, sizeof(int), cmp_int); /* 正解は qsort */
        bubble_sort(len, data);
        if (memcmp(data, expected, sizeof(int) * (size_t)len) != 0) {
            failures++;
            if (failures <= 3) {
                printf("MISMATCH at trial %d (len=%d)\n", trial, len);
            }
        }
    }
    printf("trials = %d, failures = %d\n", TRIALS, failures);
    return failures != 0;
}
