#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void bubble_sort(int n, int *arr);

static double now_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9;
}

int main(void) {
    const int sizes[] = {100, 200, 500, 1000, 2000, 5000, 10000, 20000};
    const int num_sizes = (int)(sizeof(sizes) / sizeof(sizes[0]));
    int s = 0;

    srand(2026);
    printf("size,best_time\n");
    for (s = 0; s < num_sizes; s++) {
        int n = sizes[s];
        int reps = (n <= 1000) ? 100 : (n <= 10000) ? 20 : 3;
        int *arr = malloc(sizeof(int) * (size_t)n);
        double best = 1e30; /* 全試行のうち最短の時間（外乱に強い） */
        int r = 0;
        if (arr == NULL) {
            return 1;
        }
        for (r = 0; r < reps; r++) {
            int i = 0;
            double t0 = 0.0;
            double elapsed = 0.0;
            for (i = 0; i < n; i++) {
                arr[i] = rand();
            }
            t0 = now_sec();
            bubble_sort(n, arr);
            elapsed = now_sec() - t0;
            if (elapsed < best) {
                best = elapsed;
            }
        }
        printf("%d,%.9f\n", n, best);
        free(arr);
    }
    return 0;
}
