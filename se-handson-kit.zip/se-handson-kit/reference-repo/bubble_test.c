#include <stddef.h>
#include <stdio.h>
#include <string.h>

void bubble_sort(int n, int *arr);

static int failures = 0;

static void check(const char *name, int n, int *input, const int *expect) {
    bubble_sort(n, input);
    if (n > 0 && memcmp(input, expect, sizeof(int) * (size_t)n) != 0) {
        printf("%-12s: FAIL\n", name);
        failures++;
    } else {
        printf("%-12s: PASS\n", name);
    }
}

int main(void) {
    int sorted[5] = {1, 2, 3, 4, 5};
    int sorted_e[5] = {1, 2, 3, 4, 5};
    int reversed[5] = {5, 4, 3, 2, 1};
    int reversed_e[5] = {1, 2, 3, 4, 5};
    int mixed[6] = {3, -1, 2, 3, 0, -1};
    int mixed_e[6] = {-1, -1, 0, 2, 3, 3};
    int one[1] = {42};
    int one_e[1] = {42};

    check("sorted", 5, sorted, sorted_e);
    check("reversed", 5, reversed, reversed_e);
    check("mixed", 6, mixed, mixed_e);
    check("one element", 1, one, one_e);
    check("empty", 0, one, one_e);
    bubble_sort(3, NULL); /* 落ちなければ合格 */
    printf("%-12s: PASS\n", "NULL");

    if (failures == 0) {
        printf("all tests passed\n");
    } else {
        printf("%d test(s) failed\n", failures);
    }
    return failures != 0;
}
