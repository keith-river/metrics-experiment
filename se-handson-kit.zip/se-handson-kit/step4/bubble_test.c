#include <assert.h>
#include <stdio.h>
#include <string.h>

void bubble_sort(int n, int *arr);

int main(void) {
    int input1[5] = {1, 2, 3, 4, 5};
    int expect1[5] = {1, 2, 3, 4, 5};

    bubble_sort(5, input1);
    assert(memcmp(input1, expect1, sizeof(input1)) == 0);

    printf("test succeeded\n");
    return 0;
}
