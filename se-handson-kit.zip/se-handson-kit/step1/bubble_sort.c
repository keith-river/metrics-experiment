void bubble_sort(int n, int *a)
{ int i, j;
  for (i = 0; i < n; i++) {
     for (j = 1; j < n - i; j++) {
         if (a[j - 1] < a[j]) {
             int t = a[j - 1];
             a[j - 1] = a[j];
             a[j] = t;
         }
    }    
  }
}
