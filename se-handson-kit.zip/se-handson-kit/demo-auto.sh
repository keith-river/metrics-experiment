#!/bin/bash
# ハンズオン全工程を自動で再生する（リハーサル・非常用）。
#   使い方: bash demo-auto.sh <作業ディレクトリ> [ログ保存先]
# 作業ディレクトリは新規（なければ作る）。中身があれば中止する。
set -u
KIT="$(cd "$(dirname "$0")" && pwd)"
. "$KIT/env.sh"
WORK="${1:?作業ディレクトリを指定してください}"; LOGS="${2:-}"
[ -n "$LOGS" ] && { mkdir -p "$LOGS"; LOGS="$(cd "$LOGS" && pwd)"; }
mkdir -p "$WORK"; [ -z "$(ls -A "$WORK")" ] || { echo "$WORK は空ではありません"; exit 1; }
cd "$WORK" || exit 1
TR=$'Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>\nClaude-Session: https://claude.ai/code/session_01TUADZ3hqiyMDahPCXcjX2G'
export GIT_AUTHOR_NAME="${GIT_AUTHOR_NAME:-Handson Demo}" GIT_AUTHOR_EMAIL="${GIT_AUTHOR_EMAIL:-demo@example.com}"
export GIT_COMMITTER_NAME="$GIT_AUTHOR_NAME" GIT_COMMITTER_EMAIL="$GIT_AUTHOR_EMAIL"
export GIT_CONFIG_GLOBAL=/dev/null GIT_PAGER=cat
# log NAME 'コマンド文字列' : 実行して表示し、必要ならログに保存
log() { local n=$1; shift; local out; out=$({ echo "\$ $1"; bash -c "$1" 2>&1; echo "(終了コード: $?)"; } ); echo "$out"; echo
        # ログ保存時は、環境依存の部分を配布資料向けの表記に直す
        [ -n "$LOGS" ] && printf '%s\n' "$out" | sed -e "s#$(pwd)#~/se-handson#g" \
            -e '/using JSON module/d' -e "s#$LCOV_GCOV#\$LCOV_GCOV#g" \
            -e "s#\b$GCOV\b#\$GCOV#g" -e "s#\b$CC\b#\$CC#g" > "$LOGS/$n.log"; return 0; }
commit() { git add -A && git commit -q -m "$1" -m "$TR"; }
step() { echo; echo "=================== $1"; }

step "0. リポジトリを作る"
git init -q -b main
cp "$KIT"/step0/.clang-format "$KIT"/step0/.gitignore .
commit "chore: .clang-format と .gitignore を追加"
log 00_status 'git log --oneline'

step "1. 粗削り版を書く"
git switch -q -c step1-draft
cp "$KIT"/step1/bubble_sort.c .
log 01_gcc "$CC -Wall -Wextra -c bubble_sort.c"
commit "feat: バブルソート粗削り版"
log 01_log 'git log --oneline'

step "2. clang-format（整形）"
git switch -q -c step2-format
clang-format -i bubble_sort.c
log 02_diff 'git diff'
log 02_diff_w 'git diff -w'
commit "style: clang-format を適用（整形のみ）"

step "3. clang-tidy（リンタ）"
git switch -q -c step3-lint
log 03_tidy "clang-tidy -checks='*' bubble_sort.c --"
cp "$KIT"/step3/bubble_sort.c .
log 03_tidy_after "clang-tidy -checks='*' bubble_sort.c --"
log 03_diff 'git diff'
commit "refactor: clang-tidy の指摘に対応（命名・変数初期化）"

step "4. テストを書く（ここで落ちる）"
git switch -q -c step4-test
cp "$KIT"/step4/bubble_test.c .
log 04_test "$CC -g -W -Wall bubble_test.c bubble_sort.c && ./a.out"
commit "test: 最初のテストを追加（失敗する）"

step "5. 修正する"
git switch -q -c step5-fix
cp "$KIT"/step5/bubble_sort.c .
log 05_diff 'git diff'
log 05_test "$CC -g -W -Wall bubble_test.c bubble_sort.c && ./a.out"
commit "fix: 比較の向きを修正（降順→昇順）、NULL・短い配列を早期return"

step "6. カバレッジ"
git switch -q -c step6-coverage
log 06_cov1 "$CC -c -g -W -Wall -coverage bubble_test.c bubble_sort.c && $CC -coverage bubble_test.o bubble_sort.o && ./a.out && $GCOV -b bubble_sort.c"
log 06_gcov_before "grep -v -e '^branch' -e '^call' bubble_sort.c.gcov"
cp "$KIT"/step6/bubble_test.c .
rm -f *.o *.gcda *.gcno *.gcov
log 06_cov2 "$CC -c -g -W -Wall -coverage bubble_test.c bubble_sort.c && $CC -coverage bubble_test.o bubble_sort.o && ./a.out && $GCOV -b bubble_sort.c"
log 06_gcov_after "grep -v -e '^branch' -e '^call' bubble_sort.c.gcov"
log 06_lcov "lcov --capture --directory . --output-file cov.info --rc branch_coverage=1 --gcov-tool '$LCOV_GCOV' --quiet && lcov --extract cov.info '*/bubble_sort.c' --output-file cov_sort.info --rc branch_coverage=1 --quiet && lcov --summary cov_sort.info --rc branch_coverage=1 --gcov-tool '$LCOV_GCOV'"
log 06_diff_test 'git diff --stat'
commit "test: 分岐を網羅するテストを追加（行・分岐カバレッジ100%）"

step "7. （予備）ランダムテストとベンチマーク"
git switch -q -c step7-random-bench
cp "$KIT"/step7/*.c .
log 07_random "$CC -g -W -Wall bubble_randomtest.c bubble_sort.c -o rtest && ./rtest"
log 07_bench "$CC -W -Wall -O2 bubble_bench.c bubble_sort.c -o bench && ./bench"
rm -f rtest
commit "test: ランダムテストとベンチマークを追加"

git switch -q main && git merge -q --ff-only step6-coverage
log 08_branches 'git branch -v'
log 08_graph 'git log --oneline --graph --all --decorate'
