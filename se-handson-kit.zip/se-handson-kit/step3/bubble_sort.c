void bubble_sort(int n, int *arr) {
    int i = 0;
    int j = 0;
    for (i = 0; i < n; i++) {
        for (j = 1; j < n - i; j++) {
            if (arr[j - 1] < arr[j]) {
                int tmp = arr[j - 1];
                arr[j - 1] = arr[j];
                arr[j] = tmp;
            }
        }
    }
}
