# source して使う:  . ~/se-handson-kit/env.sh
# CC / GCOV / LCOV_GCOV を、使えるツールに合わせて決める。
KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)"
CC=gcc; GCOV=gcov; LCOV_GCOV=gcov
for v in 15 14 13 12; do               # Homebrew の gcc (brew install gcc)
  if command -v gcc-$v >/dev/null 2>&1 && command -v gcov-$v >/dev/null 2>&1; then
    CC=gcc-$v; GCOV=gcov-$v; LCOV_GCOV=$(command -v gcov-$v); break
  fi
done
if [ "$CC" = gcc ] && gcc --version 2>/dev/null | grep -qi clang; then
  # Mac の標準 gcc は Apple clang の別名。gcov も llvm-cov gcov で代用する
  GCOV="llvm-cov gcov"; LCOV_GCOV="$KIT_DIR/bin/llvm-gcov.sh"
  command -v llvm-cov >/dev/null 2>&1 || GCOV="xcrun llvm-cov gcov"
fi
export CC GCOV LCOV_GCOV KIT_DIR
